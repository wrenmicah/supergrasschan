/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Trophy, Play, RotateCcw, ArrowLeft, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// --- Constants ---
const GRAVITY = 0.4;
const JUMP_STRENGTH = -14;
const PLAYER_WIDTH = 80; // Larger for better visibility
const PLAYER_HEIGHT = 80;
const PLATFORM_HEIGHT = 24;
const INITIAL_PLATFORM_COUNT = 12; // More platforms since they are bigger
const SCROLL_THRESHOLD = 0.4; // Scroll earlier to keep player in view

// Sprite Sheet Constants (Based on the 4x2 grid)
const SPRITE_URL = 'https://user.uploads.dev/file/c5be6b5bcdd3fd7a60a17ced9929438e.png';
const TITLE_IMAGE = 'https://user.uploads.dev/file/762360558804045af8a0ba89faa0fb32.png';
const SPRITE_COLS = 1;
const SPRITE_ROWS = 1;
const START_SOUND_URL = 'https://user.uploads.dev/file/81f674b32f5dd2888b485585fe731b90.wav';
const BG_MUSIC_URL = 'https://opengameart.org/sites/default/files/Curious%20Critters%20%28Extended%20Version%29%201_0.mp3';
const COLLECTIBLE_URL = 'https://user.uploads.dev/file/5d15064dc2d4ac6794310e6800c9d8fc.png';
const NUGGET_URL = 'https://user.uploads.dev/file/3780140efb39ea7e0b35b7a7edf9012c.png';
const MUSHROOM_URL = 'https://user.uploads.dev/file/10ae5386f34902309597daea1c44c1b3.png';
const DOUBLE_POINTS_DURATION = 7000;
const RAINBOW_DURATION = 7000;
const SPEED_BOOST = 1.25;
const MUSHROOM_POINTS = 150;

type GameState = 'LOADING' | 'START' | 'PLAYING' | 'GAMEOVER';

type PlatformType = 'grassy' | 'stone' | 'icy' | 'cloud' | 'starry' | 'metal' | 'lava' | 'golden' | 'ocean' | 'japan' | 'france' | 'ireland';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  life: number;
  maxLife: number;
  type: 'leaf' | 'dust' | 'snow' | 'wisp' | 'spark' | 'ember' | 'glitter';
}

interface Platform {
  x: number;
  y: number;
  width: number;
  type: PlatformType;
  scored: boolean;
  collectible?: {
    x: number;
    y: number;
    width: number;
    height: number;
    collected: boolean;
  };
  nuggets?: {
    x: number;
    y: number;
    width: number;
    height: number;
    collected: boolean;
  }[];
  mushroom?: {
    x: number;
    y: number;
    width: number;
    height: number;
    collected: boolean;
  };
}

interface Player {
  x: number;
  y: number;
  vx: number;
  vy: number;
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gameState, setGameState] = useState<GameState>('LOADING');
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const [loadProgress, setLoadProgress] = useState(0);
  
  // Game state refs to avoid re-renders during loop
  const playerRef = useRef<Player>({ x: 0, y: 0, vx: 0, vy: 0 });
  const platformsRef = useRef<Platform[]>([]);
  const scrollOffsetRef = useRef(0);
  const hasStartedRef = useRef(false);
  const startTimeRef = useRef(0);
  const keysRef = useRef<{ [key: string]: boolean }>({});
  const requestRef = useRef<number>(null);
  const lastTimeRef = useRef<number>(0);
  const spriteSheetRef = useRef<HTMLImageElement | null>(null);
  const facingLeftRef = useRef(false);
  const startSoundRef = useRef<HTMLAudioElement | null>(null);
  const bgMusicRef = useRef<HTMLAudioElement | null>(null);
  const collectibleImgRef = useRef<HTMLImageElement | null>(null);
  const nuggetImgRef = useRef<HTMLImageElement | null>(null);
  const mushroomImgRef = useRef<HTMLImageElement | null>(null);
  const doublePointsTimerRef = useRef(0);
  const rainbowTimerRef = useRef(0);
  const totalSuccessfulJumpsRef = useRef(0);

  // Load sprite sheet and sounds
  useEffect(() => {
    const assets = [
      { type: 'image', url: SPRITE_URL, ref: spriteSheetRef },
      { type: 'image', url: TITLE_IMAGE },
      { type: 'audio', url: START_SOUND_URL, ref: startSoundRef },
      { type: 'audio', url: BG_MUSIC_URL, ref: bgMusicRef },
      { type: 'image', url: COLLECTIBLE_URL, ref: collectibleImgRef },
      { type: 'image', url: NUGGET_URL, ref: nuggetImgRef },
      { type: 'image', url: MUSHROOM_URL, ref: mushroomImgRef }
    ];

    let loadedCount = 0;
    const totalAssets = assets.length;

    const onAssetLoad = () => {
      loadedCount++;
      setLoadProgress(Math.floor((loadedCount / totalAssets) * 100));
      if (loadedCount === totalAssets) {
        setTimeout(() => setGameState('START'), 500); // Small delay for smoothness
      }
    };

    assets.forEach(asset => {
      if (asset.type === 'image') {
        const img = new Image();
        img.crossOrigin = "anonymous";
        img.onload = onAssetLoad;
        img.onerror = () => {
          console.warn(`Image failed to load: ${asset.url}`);
          onAssetLoad();
        };
        img.src = asset.url;
        if (asset.ref) asset.ref.current = img;
      } else {
        const audio = new Audio();
        
        // Set listeners BEFORE setting src
        const handleLoad = () => {
          audio.oncanplaythrough = null;
          audio.onerror = null;
          if (asset.url === BG_MUSIC_URL) {
            audio.loop = true;
            audio.volume = 0.5; // Background music slightly quieter
          }
          onAssetLoad();
        };

        const handleError = () => {
          audio.oncanplaythrough = null;
          audio.onerror = null;
          console.error(`Audio Load Error for ${asset.url}:`, audio.error);
          onAssetLoad();
        };

        audio.oncanplaythrough = handleLoad;
        audio.onerror = handleError;

        audio.src = asset.url;
        if (asset.ref) asset.ref.current = audio;
      }
    });

    return () => {
    };
  }, []);

  const particlesRef = useRef<Particle[]>([]);
  const audioCtxRef = useRef<AudioContext | null>(null);

  const initAudio = () => {
    if (!audioCtxRef.current) {
      audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
  };

  const playJumpSound = () => {
    if (!audioCtxRef.current) return;
    const ctx = audioCtxRef.current;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(400, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(800, ctx.currentTime + 0.1);

    gain.gain.setValueAtTime(0.1, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.1);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + 0.1);
    
    // Neko "mew" sound (higher pitch)
    const mewOsc = ctx.createOscillator();
    const mewGain = ctx.createGain();
    mewOsc.type = 'sine';
    mewOsc.frequency.setValueAtTime(1200, ctx.currentTime);
    mewOsc.frequency.exponentialRampToValueAtTime(1500, ctx.currentTime + 0.05);
    mewGain.gain.setValueAtTime(0.05, ctx.currentTime);
    mewGain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.1);
    mewOsc.connect(mewGain);
    mewGain.connect(ctx.destination);
    mewOsc.start();
    mewOsc.stop(ctx.currentTime + 0.1);
  };

  const playLandSound = () => {
    if (!audioCtxRef.current) return;
    const ctx = audioCtxRef.current;
    const bufferSize = ctx.sampleRate * 0.05;
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noise = ctx.createBufferSource();
    noise.buffer = buffer;
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(400, ctx.currentTime);
    
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.05, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.05);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);
    noise.start();
  };

  const playGameOverSound = () => {
    if (!audioCtxRef.current) return;
    const ctx = audioCtxRef.current;
    
    // Sad descending mew/cry
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    
    osc.type = 'sine';
    osc.frequency.setValueAtTime(1000, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(400, ctx.currentTime + 0.6);
    
    gain.gain.setValueAtTime(0.1, ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.6);
    
    osc.connect(gain);
    gain.connect(ctx.destination);
    
    osc.start();
    osc.stop(ctx.currentTime + 0.6);
    
    // Dissonant second tone for "cry" effect
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(1050, ctx.currentTime);
    osc2.frequency.exponentialRampToValueAtTime(420, ctx.currentTime + 0.6);
    gain2.gain.setValueAtTime(0.03, ctx.currentTime);
    gain2.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.6);
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start();
    osc2.stop(ctx.currentTime + 0.6);
  };

  const playLeafSound = () => {
    if (!audioCtxRef.current) return;
    const ctx = audioCtxRef.current;
    
    // Sparkle/Magic sound
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    
    osc.type = 'sine';
    osc.frequency.setValueAtTime(800, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(1600, ctx.currentTime + 0.1);
    osc.frequency.exponentialRampToValueAtTime(1200, ctx.currentTime + 0.2);
    osc.frequency.exponentialRampToValueAtTime(2400, ctx.currentTime + 0.3);
    
    gain.gain.setValueAtTime(0.1, ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.3);
    
    osc.connect(gain);
    gain.connect(ctx.destination);
    
    osc.start();
    osc.stop(ctx.currentTime + 0.3);
  };

  const playNuggetSound = () => {
    if (!audioCtxRef.current) return;
    const ctx = audioCtxRef.current;
    
    // Short "ping" sound
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    
    osc.type = 'sine';
    osc.frequency.setValueAtTime(1200, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(1800, ctx.currentTime + 0.05);
    
    gain.gain.setValueAtTime(0.05, ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.1);
    
    osc.connect(gain);
    gain.connect(ctx.destination);
    
    osc.start();
    osc.stop(ctx.currentTime + 0.1);
  };

  const playMushroomSound = () => {
    if (!audioCtxRef.current) return;
    const ctx = audioCtxRef.current;
    
    // Fun "pop" or "boing" sound
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(400, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(800, ctx.currentTime + 0.1);
    osc.frequency.exponentialRampToValueAtTime(600, ctx.currentTime + 0.2);
    
    gain.gain.setValueAtTime(0.1, ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.2);
    
    osc.connect(gain);
    gain.connect(ctx.destination);
    
    osc.start();
    osc.stop(ctx.currentTime + 0.2);
  };

  const initGame = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const width = canvas.width;
    const height = canvas.height;

    // Initial player position
    playerRef.current = {
      x: width / 2 - PLAYER_WIDTH / 2,
      y: height - PLAYER_HEIGHT - PLATFORM_HEIGHT - 10,
      vx: 0,
      vy: 0,
    };

    // Initial platforms
    const platforms: Platform[] = [];
    // Starting platform (full width)
    const startPlatform: Platform = {
      x: 0,
      y: height - PLATFORM_HEIGHT,
      width: width,
      type: 'grassy',
      scored: true, // Don't score the starting platform
    };
    platforms.push(startPlatform);

    // Generate initial set of platforms
    let lastY = height - PLATFORM_HEIGHT;
    let lastX = startPlatform.x;
    let lastWidth = startPlatform.width;
    for (let i = 0; i < INITIAL_PLATFORM_COUNT; i++) {
      const gap = 100 + Math.random() * 80;
      lastY -= gap;
      const p = generatePlatform(lastY, width, lastX, lastWidth);
      platforms.push(p);
      lastX = p.x;
      lastWidth = p.width;
    }

    platformsRef.current = platforms;
    scrollOffsetRef.current = 0;
    hasStartedRef.current = false;
    startTimeRef.current = 0;
    keysRef.current = {};
    totalSuccessfulJumpsRef.current = 0;
    rainbowTimerRef.current = 0;
    setScore(0);
  }, []);

  const generatePlatform = (y: number, canvasWidth: number, prevX?: number, prevWidth?: number): Platform => {
    const minWidth = 80;
    const maxWidth = 160;
    const width = minWidth + Math.random() * (maxWidth - minWidth);
    
    let x;
    if (prevX !== undefined && prevWidth !== undefined) {
      // Constrain x to be within reachable distance of prev platform
      // Max horizontal jump is ~300, but let's be safer (e.g. 220)
      const maxDist = 220; 
      const centerX = prevX + prevWidth / 2;
      const minX = Math.max(0, centerX - maxDist - width / 2);
      const maxX = Math.min(canvasWidth - width, centerX + maxDist - width / 2);
      x = minX + Math.random() * (maxX - minX);
    } else {
      x = Math.random() * (canvasWidth - width);
    }
    
    // Type depends on total successful jumps (progression every 50 jumps)
    const level = Math.floor(totalSuccessfulJumpsRef.current / 50);
    
    let type: PlatformType = 'grassy';
    if (level >= 11) type = 'ireland';
    else if (level === 10) type = 'france';
    else if (level === 9) type = 'japan';
    else if (level === 8) type = 'ocean';
    else if (level === 7) type = 'golden';
    else if (level === 6) type = 'lava';
    else if (level === 5) type = 'metal';
    else if (level === 4) type = 'starry';
    else if (level === 3) type = 'cloud';
    else if (level === 2) type = 'icy';
    else if (level === 1) type = 'stone';

    // Add collectible (Rare: 5% chance, in open air)
    let collectible;
    if (Math.random() < 0.05 && prevX !== undefined) {
      const cWidth = 40;
      const cHeight = 40;
      
      // Place in open air away from the platform
      // Try to find an X that is close enough to be reachable but still in the air
      let cx;
      const horizontalOffset = 40; // 40 pixels off the edge
      if (x > canvasWidth / 2) {
        // Platform is on the right, place collectible on the left
        cx = x - cWidth - horizontalOffset;
      } else {
        // Platform is on the left, place collectible on the right
        cx = x + width + horizontalOffset;
      }
      
      // Ensure cx is within bounds
      cx = Math.max(10, Math.min(canvasWidth - cWidth - 10, cx));

      collectible = {
        x: cx - x,
        y: -100 - Math.random() * 40, // 100-140 up (relative to platform top)
        width: cWidth,
        height: cHeight,
        collected: false
      };
    }

    // Add nuggets scattered above the platform
    const nuggets = [];
    const nuggetCount = 1 + Math.floor(Math.random() * 3); // 1-3 nuggets
    for (let i = 0; i < nuggetCount; i++) {
      nuggets.push({
        x: Math.random() * (width - 20),
        y: -30 - Math.random() * 60, // 30-90 pixels above
        width: 20,
        height: 20,
        collected: false
      });
    }

    // Add mushroom (Rare: 1% chance)
    let mushroom;
    if (Math.random() < 0.01 && prevX !== undefined) {
      mushroom = {
        x: Math.random() * (width - 60),
        y: -150 - Math.random() * 50,
        width: 60,
        height: 60,
        collected: false
      };
    }

    return { x, y, width, type, scored: false, collectible, nuggets, mushroom };
  };

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    const zoom = 1.0;

    ctx.save();
    // Center the zoom
    ctx.translate(width / 2, height / 2);
    ctx.scale(zoom, zoom);
    ctx.translate(-width / 2, -height / 2);

    // Background based on level (every 50 jumps)
    const level = Math.floor(totalSuccessfulJumpsRef.current / 50);
    const player = playerRef.current;
    
    // Gradient background
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    if (level >= 11) { // Ireland - Emerald Isle
      gradient.addColorStop(0, '#065f46');
      gradient.addColorStop(1, '#064e3b');
    } else if (level === 10) { // France - Tricolore subtle
      gradient.addColorStop(0, '#f8fafc');
      gradient.addColorStop(1, '#e2e8f0');
    } else if (level === 9) { // Japan - Rising Sun/Sakura
      gradient.addColorStop(0, '#fff1f2');
      gradient.addColorStop(1, '#ffe4e6');
    } else if (level === 8) { // Ocean - Deep Blue
      gradient.addColorStop(0, '#0c4a6e');
      gradient.addColorStop(1, '#075985');
    } else if (level === 7) { // Heavenly
      gradient.addColorStop(0, '#fffbeb');
      gradient.addColorStop(1, '#fef3c7');
    } else if (level === 6) { // Volcanic
      gradient.addColorStop(0, '#450a0a');
      gradient.addColorStop(1, '#7f1d1d');
    } else if (level === 5) { // Spaceship
      gradient.addColorStop(0, '#0f172a');
      gradient.addColorStop(1, '#1e293b');
    } else if (level === 4) { // Space
      gradient.addColorStop(0, '#020617');
      gradient.addColorStop(1, '#0f172a');
    } else if (level === 3) { // Sky
      gradient.addColorStop(0, '#38bdf8');
      gradient.addColorStop(1, '#bae6fd');
    } else if (level === 2) { // Icy
      gradient.addColorStop(0, '#1e3a8a');
      gradient.addColorStop(1, '#3b82f6');
    } else if (level === 1) { // Mountain
      gradient.addColorStop(0, '#475569');
      gradient.addColorStop(1, '#94a3b8');
    } else { // Forest
      gradient.addColorStop(0, '#064e3b');
      gradient.addColorStop(1, '#065f46');
    }
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);

    // Background Details
    ctx.save();
    const heightLevel = scrollOffsetRef.current;
    if (level >= 11) { // Ireland - Shamrocks/Clovers
      ctx.fillStyle = 'rgba(16, 185, 129, 0.2)';
      for (let i = 0; i < 15; i++) {
        const x = (i * 100 + heightLevel * 0.1) % width;
        const y = (i * 80 + heightLevel * 0.4) % height;
        ctx.beginPath();
        ctx.arc(x, y, 5, 0, Math.PI * 2);
        ctx.fill();
      }
    } else if (level === 10) { // France - Eiffel Tower silhouettes
      ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
      for (let i = 0; i < 3; i++) {
        const x = (i * 300 - heightLevel * 0.05) % width;
        ctx.beginPath();
        ctx.moveTo(x, height);
        ctx.lineTo(x + 20, height - 150);
        ctx.lineTo(x + 40, height);
        ctx.fill();
      }
    } else if (level === 9) { // Japan - Sakura petals
      ctx.fillStyle = '#fda4af';
      for (let i = 0; i < 20; i++) {
        const x = (i * 60 + Math.sin(heightLevel * 0.01 + i) * 30) % width;
        const y = (i * 40 + heightLevel * 0.6) % height;
        ctx.beginPath();
        ctx.ellipse(x, y, 4, 6, Math.PI / 4, 0, Math.PI * 2);
        ctx.fill();
      }
    } else if (level === 8) { // Ocean - Bubbles
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
      ctx.lineWidth = 1;
      for (let i = 0; i < 15; i++) {
        const x = (i * 80 + Math.sin(heightLevel * 0.02 + i) * 20) % width;
        const y = (height - (i * 60 + heightLevel * 0.3) % height);
        ctx.beginPath();
        ctx.arc(x, y, 8, 0, Math.PI * 2);
        ctx.stroke();
      }
    } else if (level >= 7) { // Heavenly - Clouds and light rays
      ctx.fillStyle = 'rgba(255, 255, 255, 0.3)';
      for (let i = 0; i < 5; i++) {
        ctx.beginPath();
        ctx.arc((i * 200 + heightLevel * 0.1) % width, height * 0.2, 50, 0, Math.PI * 2);
        ctx.fill();
      }
    } else if (level === 6) { // Volcanic - Embers
      ctx.fillStyle = '#f97316';
      for (let i = 0; i < 20; i++) {
        const x = (Math.sin(i + heightLevel * 0.01) * width + width) % width;
        const y = (i * 40 + heightLevel * 0.5) % height;
        ctx.fillRect(x, y, 2, 2);
      }
    } else if (level === 5 || level === 4) { // Space/Spaceship - Stars
      ctx.fillStyle = '#ffffff';
      for (let i = 0; i < 50; i++) {
        const x = (Math.sin(i) * width + width) % width;
        const y = (i * 20 + heightLevel * 0.2) % height;
        ctx.globalAlpha = Math.random();
        ctx.fillRect(x, y, 1, 1);
      }
      ctx.globalAlpha = 1;
    } else if (level === 2) { // Icy - Snow
      ctx.fillStyle = '#ffffff';
      for (let i = 0; i < 30; i++) {
        const x = (i * 50 + heightLevel * 0.2) % width;
        const y = (i * 30 + heightLevel * 0.8) % height;
        ctx.beginPath();
        ctx.arc(x, y, 2, 0, Math.PI * 2);
        ctx.fill();
      }
    } else if (level === 0) { // Forest - Tree silhouettes
      ctx.fillStyle = 'rgba(0, 0, 0, 0.1)';
      for (let i = 0; i < 4; i++) {
        const x = i * 150 - (heightLevel * 0.1) % 150;
        ctx.beginPath();
        ctx.moveTo(x, height);
        ctx.lineTo(x + 40, height - 120);
        ctx.lineTo(x + 80, height);
        ctx.fill();
      }
    }
    ctx.restore();

    // Draw platforms
    platformsRef.current.forEach(p => {
      ctx.save();
      ctx.translate(p.x, p.y);
      
      switch (p.type) {
        case 'grassy':
          ctx.fillStyle = '#4ade80';
          ctx.fillRect(0, 0, p.width, 8);
          ctx.fillStyle = '#713f12';
          ctx.fillRect(0, 8, p.width, PLATFORM_HEIGHT - 8);
          ctx.fillStyle = '#22c55e';
          for (let i = 0; i < p.width; i += 15) {
            ctx.beginPath();
            ctx.moveTo(i + 2, 0);
            ctx.lineTo(i + 5, -5);
            ctx.lineTo(i + 8, 0);
            ctx.fill();
          }
          break;
        case 'stone':
          ctx.fillStyle = '#94a3b8';
          ctx.fillRect(0, 0, p.width, 8);
          ctx.fillStyle = '#475569';
          ctx.fillRect(0, 8, p.width, PLATFORM_HEIGHT - 8);
          ctx.strokeStyle = '#1e293b';
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(10, 4); ctx.lineTo(25, 6);
          ctx.moveTo(p.width - 30, 12); ctx.lineTo(p.width - 10, 15);
          ctx.stroke();
          break;
        case 'icy':
          ctx.fillStyle = '#e0f2fe';
          ctx.fillRect(0, 0, p.width, 8);
          ctx.fillStyle = '#3b82f6';
          ctx.fillRect(0, 8, p.width, PLATFORM_HEIGHT - 8);
          ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
          ctx.fillRect(5, 2, p.width - 10, 2);
          break;
        case 'cloud':
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.roundRect(0, 0, p.width, PLATFORM_HEIGHT, 15);
          ctx.fill();
          ctx.fillStyle = '#f1f5f9';
          ctx.beginPath();
          ctx.arc(p.width * 0.3, PLATFORM_HEIGHT, 10, 0, Math.PI * 2);
          ctx.arc(p.width * 0.7, PLATFORM_HEIGHT, 8, 0, Math.PI * 2);
          ctx.fill();
          break;
        case 'starry':
          ctx.fillStyle = '#2e1065';
          ctx.fillRect(0, 0, p.width, PLATFORM_HEIGHT);
          ctx.strokeStyle = '#a855f7';
          ctx.lineWidth = 2;
          ctx.strokeRect(0, 0, p.width, PLATFORM_HEIGHT);
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(p.width * 0.2, 5, 2, 2);
          ctx.fillRect(p.width * 0.8, 12, 1, 1);
          break;
        case 'metal':
          ctx.fillStyle = '#64748b';
          ctx.fillRect(0, 0, p.width, PLATFORM_HEIGHT);
          ctx.fillStyle = '#94a3b8';
          for (let i = 0; i < 2; i++) {
            for (let j = 0; j < 2; j++) {
              ctx.beginPath();
              ctx.arc(5 + i * (p.width - 10), 5 + j * (PLATFORM_HEIGHT - 10), 2, 0, Math.PI * 2);
              ctx.fill();
            }
          }
          ctx.strokeStyle = '#334155';
          ctx.strokeRect(2, 2, p.width - 4, PLATFORM_HEIGHT - 4);
          break;
        case 'lava':
          ctx.fillStyle = '#1c1917';
          ctx.fillRect(0, 0, p.width, PLATFORM_HEIGHT);
          ctx.fillStyle = '#f97316';
          ctx.shadowBlur = 10;
          ctx.shadowColor = '#f97316';
          ctx.fillRect(10, 10, p.width - 20, 4);
          ctx.shadowBlur = 0;
          break;
        case 'golden':
          const goldGrad = ctx.createLinearGradient(0, 0, 0, PLATFORM_HEIGHT);
          goldGrad.addColorStop(0, '#fbbf24');
          goldGrad.addColorStop(1, '#b45309');
          ctx.fillStyle = goldGrad;
          ctx.fillRect(0, 0, p.width, PLATFORM_HEIGHT);
          ctx.strokeStyle = '#fef3c7';
          ctx.lineWidth = 2;
          ctx.strokeRect(4, 4, p.width - 8, PLATFORM_HEIGHT - 8);
          break;
        case 'ocean':
          // Bubble platforms
          ctx.fillStyle = 'rgba(186, 230, 253, 0.6)';
          ctx.beginPath();
          ctx.roundRect(0, 0, p.width, PLATFORM_HEIGHT, 10);
          ctx.fill();
          ctx.strokeStyle = '#ffffff';
          ctx.lineWidth = 2;
          ctx.stroke();
          // Inner bubbles
          ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
          ctx.beginPath();
          ctx.arc(15, 10, 5, 0, Math.PI * 2);
          ctx.arc(p.width - 20, 15, 7, 0, Math.PI * 2);
          ctx.fill();
          break;
        case 'japan':
          // Sakura blossom platforms
          ctx.fillStyle = '#ffe4e6';
          ctx.fillRect(0, 0, p.width, PLATFORM_HEIGHT);
          ctx.fillStyle = '#fda4af';
          // Draw some petals on the platform
          for (let i = 0; i < p.width; i += 30) {
            ctx.beginPath();
            ctx.arc(i + 15, 5, 8, 0, Math.PI * 2);
            ctx.fill();
          }
          ctx.strokeStyle = '#f43f5e';
          ctx.lineWidth = 1;
          ctx.strokeRect(0, 0, p.width, PLATFORM_HEIGHT);
          break;
        case 'france':
          // Baguette platforms
          ctx.fillStyle = '#d97706'; // Crust
          ctx.beginPath();
          ctx.roundRect(0, 0, p.width, PLATFORM_HEIGHT, 12);
          ctx.fill();
          ctx.strokeStyle = '#92400e';
          ctx.lineWidth = 2;
          ctx.stroke();
          // Score marks
          ctx.strokeStyle = '#f59e0b';
          for (let i = 20; i < p.width - 20; i += 30) {
            ctx.beginPath();
            ctx.moveTo(i, 5);
            ctx.lineTo(i + 15, PLATFORM_HEIGHT - 5);
            ctx.stroke();
          }
          break;
        case 'ireland':
          // Shamrock platforms
          ctx.fillStyle = '#15803d';
          ctx.fillRect(0, 0, p.width, PLATFORM_HEIGHT);
          ctx.fillStyle = '#166534';
          // Draw shamrocks
          for (let i = 10; i < p.width - 10; i += 40) {
            ctx.beginPath();
            ctx.arc(i, 10, 6, 0, Math.PI * 2);
            ctx.arc(i + 8, 10, 6, 0, Math.PI * 2);
            ctx.arc(i + 4, 16, 6, 0, Math.PI * 2);
            ctx.fill();
          }
          ctx.strokeStyle = '#4ade80';
          ctx.lineWidth = 2;
          ctx.strokeRect(0, 0, p.width, PLATFORM_HEIGHT);
          break;
      }

      // Draw collectible (Inside translated context)
      if (p.collectible && !p.collectible.collected) {
        const c = p.collectible;
        if (collectibleImgRef.current) {
          ctx.drawImage(collectibleImgRef.current, c.x, c.y, c.width, c.height);
        } else {
          // Fallback: Golden leaf-like shape
          ctx.fillStyle = '#fbbf24';
          ctx.beginPath();
          ctx.ellipse(c.x + c.width / 2, c.y + c.height / 2, c.width / 2, c.height / 3, Math.PI / 4, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // Draw nuggets (Inside translated context)
      if (p.nuggets) {
        p.nuggets.forEach(n => {
          if (!n.collected) {
            if (nuggetImgRef.current) {
              ctx.drawImage(nuggetImgRef.current, n.x, n.y, n.width, n.height);
            } else {
              // Fallback: Small orange circle
              ctx.fillStyle = '#f97316';
              ctx.beginPath();
              ctx.arc(n.x + n.width / 2, n.y + n.height / 2, n.width / 2, 0, Math.PI * 2);
              ctx.fill();
            }
          }
        });
      }

      // Draw mushroom (Inside translated context)
      if (p.mushroom && !p.mushroom.collected) {
        const m = p.mushroom;
        if (mushroomImgRef.current) {
          ctx.drawImage(mushroomImgRef.current, m.x, m.y, m.width, m.height);
        } else {
          // Fallback: Red mushroom with white dots
          ctx.save();
          ctx.translate(m.x + m.width / 2, m.y + m.height / 2);
          
          // Stem
          ctx.fillStyle = '#fef3c7';
          ctx.fillRect(-m.width / 6, 0, m.width / 3, m.height / 2);
          
          // Cap
          ctx.fillStyle = '#ef4444';
          ctx.beginPath();
          ctx.arc(0, 0, m.width / 2, Math.PI, 0);
          ctx.fill();
          
          // Dots
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.arc(-m.width / 4, -m.height / 4, m.width / 10, 0, Math.PI * 2);
          ctx.fill();
          ctx.beginPath();
          ctx.arc(m.width / 4, -m.height / 4, m.width / 10, 0, Math.PI * 2);
          ctx.fill();
          ctx.beginPath();
          ctx.arc(0, -m.height / 3, m.width / 10, 0, Math.PI * 2);
          ctx.fill();
          
          ctx.restore();
        }
      }
      ctx.restore();
    });

    // Draw player (Sprite)
    if (spriteSheetRef.current) {
      const img = spriteSheetRef.current;
      
      ctx.save();
      // Flip sprite if facing left
      if (facingLeftRef.current) {
        ctx.translate(player.x + PLAYER_WIDTH, player.y);
        ctx.scale(-1, 1);
        ctx.drawImage(img, 0, 0, img.width, img.height, 0, 0, PLAYER_WIDTH, PLAYER_HEIGHT);
      } else {
        ctx.drawImage(img, 0, 0, img.width, img.height, player.x, player.y, PLAYER_WIDTH, PLAYER_HEIGHT);
      }
      ctx.restore();
    } else {
      // Fallback if image not loaded
      const r = 8;
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.moveTo(player.x + r, player.y);
      ctx.lineTo(player.x + PLAYER_WIDTH - r, player.y);
      ctx.quadraticCurveTo(player.x + PLAYER_WIDTH, player.y, player.x + PLAYER_WIDTH, player.y + r);
      ctx.lineTo(player.x + PLAYER_WIDTH, player.y + PLAYER_HEIGHT - r);
      ctx.quadraticCurveTo(player.x + PLAYER_WIDTH, player.y + PLAYER_HEIGHT, player.x + PLAYER_WIDTH - r, player.y + PLAYER_HEIGHT);
      ctx.lineTo(player.x + r, player.y + PLAYER_HEIGHT);
      ctx.quadraticCurveTo(player.x, player.y + PLAYER_HEIGHT, player.x, player.y + PLAYER_HEIGHT - r);
      ctx.lineTo(player.x, player.y + r);
      ctx.quadraticCurveTo(player.x, player.y, player.x + r, player.y);
      ctx.closePath();
      ctx.fill();
    }

    // Draw Foreground Particles
    particlesRef.current.forEach(p => {
      ctx.save();
      ctx.globalAlpha = p.life / p.maxLife;
      ctx.fillStyle = p.color;
      if (p.type === 'leaf') {
        ctx.translate(p.x, p.y);
        ctx.rotate(p.life * 0.1);
        ctx.beginPath();
        ctx.ellipse(0, 0, p.size, p.size / 2, 0, 0, Math.PI * 2);
        ctx.fill();
      } else if (p.type === 'snow') {
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      } else if (p.type === 'glitter') {
        ctx.shadowBlur = 5;
        ctx.shadowColor = p.color;
        ctx.beginPath();
        ctx.moveTo(p.x, p.y - p.size);
        ctx.lineTo(p.x + p.size, p.y);
        ctx.lineTo(p.x, p.y + p.size);
        ctx.lineTo(p.x - p.size, p.y);
        ctx.closePath();
        ctx.fill();
      } else {
        ctx.fillRect(p.x - p.size / 2, p.y - p.size / 2, p.size, p.size);
      }
      ctx.restore();
    });

    // Green filter for double points
    if (doublePointsTimerRef.current > 0) {
      ctx.save();
      ctx.fillStyle = 'rgba(0, 255, 0, 0.15)';
      ctx.fillRect(0, 0, width, height);
      
      ctx.fillStyle = '#4ade80';
      ctx.font = 'bold 24px sans-serif';
      ctx.textAlign = 'right';
      ctx.shadowBlur = 10;
      ctx.shadowColor = '#000';
      ctx.fillText('2X POINTS!', width - 20, 40);
      ctx.restore();
    }

    // Rainbow Filter
    if (rainbowTimerRef.current > 0) {
      ctx.save();
      ctx.globalAlpha = 0.2;
      const rainbowGrad = ctx.createLinearGradient(0, 0, width, 0);
      rainbowGrad.addColorStop(0, 'red');
      rainbowGrad.addColorStop(0.17, 'orange');
      rainbowGrad.addColorStop(0.33, 'yellow');
      rainbowGrad.addColorStop(0.5, 'green');
      rainbowGrad.addColorStop(0.67, 'blue');
      rainbowGrad.addColorStop(0.83, 'indigo');
      rainbowGrad.addColorStop(1, 'violet');
      ctx.fillStyle = rainbowGrad;
      ctx.fillRect(0, 0, width, height);
      ctx.restore();
      
      // Also apply a hue-rotate effect to the whole screen if possible
      canvas.style.filter = `hue-rotate(${Date.now() % 360}deg)`;
    } else {
      canvas.style.filter = 'none';
    }

    ctx.restore();
  }, [gameState]);

  const update = useCallback((time: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // dt calculation
    const dt = time - lastTimeRef.current;
    lastTimeRef.current = time;

    const player = playerRef.current;
    const platforms = platformsRef.current;
    const width = canvas.width;
    const height = canvas.height;

    // Update double points timer
    if (doublePointsTimerRef.current > 0) {
      doublePointsTimerRef.current -= dt;
      if (doublePointsTimerRef.current < 0) doublePointsTimerRef.current = 0;
    }

    // Movement
    const onIcy = platforms.some(p => 
      p.type === 'icy' && 
      Math.abs(player.y + PLAYER_HEIGHT - p.y) < 2 && 
      player.x + PLAYER_WIDTH * 0.7 > p.x && 
      player.x + PLAYER_WIDTH * 0.3 < p.x + p.width
    );

    const isRainbow = rainbowTimerRef.current > 0;
    const speedMultiplier = isRainbow ? SPEED_BOOST : 1.0;

    const friction = onIcy ? 0.98 : 0.8;
    const accel = (onIcy ? 0.2 : 1.5) * speedMultiplier;
    const maxSpeed = 5 * speedMultiplier;

    if (keysRef.current['ArrowLeft'] || keysRef.current['a']) {
      player.vx = Math.max(player.vx - accel, -maxSpeed);
      facingLeftRef.current = true;
    } else if (keysRef.current['ArrowRight'] || keysRef.current['d']) {
      player.vx = Math.min(player.vx + accel, maxSpeed);
      facingLeftRef.current = false;
    } else {
      player.vx *= friction;
      if (Math.abs(player.vx) < 0.1) player.vx = 0;
    }

    player.x += player.vx;
    player.vy += GRAVITY;
    player.y += player.vy;

    // Screen wrap
    if (player.x + PLAYER_WIDTH < 0) player.x = width;
    if (player.x > width) player.x = -PLAYER_WIDTH;

    // Particle Update
    particlesRef.current.forEach(p => {
      p.x += p.vx * speedMultiplier;
      p.y += p.vy * speedMultiplier;
      p.life--;
    });
    particlesRef.current = particlesRef.current.filter(p => p.life > 0);

    // Timers
    if (rainbowTimerRef.current > 0) {
      rainbowTimerRef.current -= dt;
      if (rainbowTimerRef.current < 0) rainbowTimerRef.current = 0;
    }

    // Particle Generation
    const level = Math.floor(totalSuccessfulJumpsRef.current / 50);
    if (Math.random() < 0.1) {
      let pType: Particle['type'] = 'leaf';
      let pColor = '#4ade80';
      if (level >= 7) { pType = 'glitter'; pColor = '#fbbf24'; }
      else if (level === 6) { pType = 'ember'; pColor = '#f97316'; }
      else if (level === 5) { pType = 'spark'; pColor = '#94a3b8'; }
      else if (level === 4) { pType = 'glitter'; pColor = '#a855f7'; }
      else if (level === 3) { pType = 'wisp'; pColor = '#ffffff'; }
      else if (level === 2) { pType = 'snow'; pColor = '#ffffff'; }
      else if (level === 1) { pType = 'dust'; pColor = '#94a3b8'; }

      particlesRef.current.push({
        x: Math.random() * width,
        y: -20,
        vx: (Math.random() - 0.5) * 2,
        vy: 1 + Math.random() * 2,
        size: 2 + Math.random() * 4,
        color: pColor,
        life: 200,
        maxLife: 200,
        type: pType
      });
    }

    // Auto-scrolling logic
    if (hasStartedRef.current) {
      const timeSinceStart = time - startTimeRef.current;
      const gracePeriod = 5000; // 5 seconds grace period

      if (timeSinceStart > gracePeriod) {
        // Base speed + slight increase as you get higher
        const baseSpeed = 0.6;
        // Slower difficulty increase: divide by 15000 instead of 5000, and cap at 1.5
        const speedIncrease = Math.min(1.5, scrollOffsetRef.current / 15000);
        const currentScrollSpeed = (baseSpeed + speedIncrease) * speedMultiplier;
        
        player.y += currentScrollSpeed;
        scrollOffsetRef.current += currentScrollSpeed;
        platforms.forEach(p => { p.y += currentScrollSpeed; });
      }
    }

    // Collision detection
    platforms.forEach(platform => {
      // Collectible collision
      if (platform.collectible && !platform.collectible.collected) {
        const c = platform.collectible;
        if (
          player.x + PLAYER_WIDTH * 0.7 > platform.x + c.x &&
          player.x + PLAYER_WIDTH * 0.3 < platform.x + c.x + c.width &&
          player.y + PLAYER_HEIGHT > platform.y + c.y &&
          player.y < platform.y + c.y + c.height
        ) {
          c.collected = true;
          setScore(prev => prev + 100); // Collectibles are now the only source of points
          doublePointsTimerRef.current = DOUBLE_POINTS_DURATION;
          playLeafSound();
        }
      }

      // Nugget collision
      if (platform.nuggets) {
        platform.nuggets.forEach(n => {
          if (!n.collected) {
            if (
              player.x + PLAYER_WIDTH * 0.7 > platform.x + n.x &&
              player.x + PLAYER_WIDTH * 0.3 < platform.x + n.x + n.width &&
              player.y + PLAYER_HEIGHT > platform.y + n.y &&
              player.y < platform.y + n.y + n.height
            ) {
              n.collected = true;
              setScore(prev => prev + 10);
              playNuggetSound();
            }
          }
        });
      }

      // Mushroom collision
      if (platform.mushroom && !platform.mushroom.collected) {
        const m = platform.mushroom;
        if (
          player.x + PLAYER_WIDTH * 0.7 > platform.x + m.x &&
          player.x + PLAYER_WIDTH * 0.3 < platform.x + m.x + m.width &&
          player.y + PLAYER_HEIGHT > platform.y + m.y &&
          player.y < platform.y + m.y + m.height
        ) {
          m.collected = true;
          setScore(prev => prev + MUSHROOM_POINTS);
          rainbowTimerRef.current = RAINBOW_DURATION;
          playMushroomSound();
        }
      }
    });

    if (player.vy > 0) {
      for (const platform of platforms) {
        if (
          player.x + PLAYER_WIDTH * 0.7 > platform.x &&
          player.x + PLAYER_WIDTH * 0.3 < platform.x + platform.width &&
          player.y + PLAYER_HEIGHT > platform.y &&
          player.y + PLAYER_HEIGHT < platform.y + PLATFORM_HEIGHT + player.vy
        ) {
          player.y = platform.y - PLAYER_HEIGHT;
          player.vy = JUMP_STRENGTH;
          playLandSound();
          playJumpSound();
          
          // Start auto-scrolling after the first jump
          if (!hasStartedRef.current && platform.scored) {
            hasStartedRef.current = true;
            startTimeRef.current = performance.now();
          }
          
          if (!platform.scored) {
            platform.scored = true;
            totalSuccessfulJumpsRef.current++;
            if (!hasStartedRef.current) {
              hasStartedRef.current = true;
              startTimeRef.current = performance.now();
            }
          }
          break;
        }
      }
    }

    // Scrolling logic
    if (player.y < height * SCROLL_THRESHOLD) {
      const diff = height * SCROLL_THRESHOLD - player.y;
      player.y += diff;
      scrollOffsetRef.current += diff;
      platforms.forEach(p => { p.y += diff; });
    }

    // Platform management
    platformsRef.current = platforms.filter(p => p.y < height + 150);
    while (platformsRef.current.length < INITIAL_PLATFORM_COUNT + 8) {
      const highestPlatform = platformsRef.current.reduce((prev, curr) => (prev.y < curr.y ? prev : curr));
      const highestY = highestPlatform.y;
      const gap = 100 + Math.random() * 100;
      platformsRef.current.push(generatePlatform(highestY - gap, width, highestPlatform.x, highestPlatform.width));
    }

    // Fail state
    if (player.y > height) {
      playGameOverSound();
      if (bgMusicRef.current) {
        bgMusicRef.current.pause();
        bgMusicRef.current.currentTime = 0;
      }
      setGameState('GAMEOVER');
      setHighScore(prev => Math.max(prev, score));
    }

    draw();
  }, [draw, score]);

  useEffect(() => {
    if (gameState !== 'PLAYING') {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
      return;
    }

    const loop = (time: number) => {
      update(time);
      if (gameState === 'PLAYING') {
        requestRef.current = requestAnimationFrame(loop);
      }
    };

    lastTimeRef.current = performance.now();
    requestRef.current = requestAnimationFrame(loop);

    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [gameState, update]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      keysRef.current[e.key] = true;
      if (gameState === 'START' && e.key === ' ') startGame();
      if (gameState === 'GAMEOVER' && e.key === ' ') startGame();
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      keysRef.current[e.key] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('blur', () => {
      keysRef.current = {};
    });

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('blur', () => {
        keysRef.current = {};
      });
    };
  }, [gameState]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const updateSize = () => {
      const container = canvas.parentElement;
      if (container) {
        canvas.width = container.clientWidth;
        canvas.height = container.clientHeight;
        if (gameState === 'START') {
          initGame();
          draw();
        }
      }
    };

    updateSize();
    window.addEventListener('resize', updateSize);
    return () => window.removeEventListener('resize', updateSize);
  }, [initGame, gameState, draw]);

  const startGame = () => {
    initAudio();
    if (audioCtxRef.current && audioCtxRef.current.state === 'suspended') {
      audioCtxRef.current.resume();
    }
    
    // Stop background music if it was playing
    if (bgMusicRef.current) {
      bgMusicRef.current.pause();
      bgMusicRef.current.currentTime = 0;
    }

    if (startSoundRef.current) {
      startSoundRef.current.currentTime = 0;
      startSoundRef.current.play().catch(e => console.error("Audio play failed:", e));
      
      // Play background music after start sound ends
      const playMusic = () => {
        if (bgMusicRef.current) {
          bgMusicRef.current.play().catch(e => console.error("BG Music play failed:", e));
        }
        startSoundRef.current?.removeEventListener('ended', playMusic);
      };
      startSoundRef.current.addEventListener('ended', playMusic);
    } else {
      // If no start sound, play music immediately
      if (bgMusicRef.current) {
        bgMusicRef.current.play().catch(e => console.error("BG Music play failed:", e));
      }
    }
    
    initGame();
    setGameState('PLAYING');
  };

  // Touch controls for mobile
  const handleTouchStart = (dir: 'left' | 'right') => {
    keysRef.current[dir === 'left' ? 'ArrowLeft' : 'ArrowRight'] = true;
    facingLeftRef.current = dir === 'left';
  };
  const handleTouchEnd = (dir: 'left' | 'right') => {
    keysRef.current[dir === 'left' ? 'ArrowLeft' : 'ArrowRight'] = false;
  };

  return (
    <div className="relative w-full h-screen bg-slate-900 flex items-center justify-center overflow-hidden font-sans">
      {/* Game Container */}
      <div className="relative w-full max-w-lg h-full bg-white shadow-2xl overflow-hidden">
        <canvas
          ref={canvasRef}
          className="w-full h-full block touch-none"
          id="game-canvas"
        />

        {/* UI Overlay */}
        <div className="absolute top-0 left-0 w-full p-6 flex justify-between items-start pointer-events-none">
          <div className="bg-black/20 backdrop-blur-md px-4 py-2 rounded-full border border-white/20">
            <span className="text-white font-bold text-2xl tracking-tighter">{score}</span>
            <span className="text-white/60 text-xs ml-2 uppercase font-semibold">Points</span>
          </div>
          
          {highScore > 0 && (
            <div className="bg-amber-500/20 backdrop-blur-md px-4 py-2 rounded-full border border-amber-500/30 flex items-center gap-2">
              <Trophy className="w-4 h-4 text-amber-500" />
              <span className="text-amber-500 font-bold">{highScore}</span>
            </div>
          )}
        </div>

        {/* Loading Screen */}
      {gameState === 'LOADING' && (
        <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-slate-950 text-white">
          <div className="w-64 h-2 bg-slate-800 rounded-full overflow-hidden mb-4">
            <div 
              className="h-full bg-emerald-500 transition-all duration-300"
              style={{ width: `${loadProgress}%` }}
            />
          </div>
          <p className="text-emerald-400 font-mono text-sm uppercase tracking-widest animate-pulse">
            Loading Assets... {loadProgress}%
          </p>
        </div>
      )}

      {/* Start Screen */}
        <AnimatePresence>
          {gameState === 'START' && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-slate-900/90 backdrop-blur-sm flex flex-col items-center justify-center p-8 text-center overflow-hidden"
            >
              <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(74,222,128,0.15)_0%,transparent_70%)]" />
              <motion.div
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.2 }}
                className="flex flex-col items-center"
              >
                <motion.img 
                  src={TITLE_IMAGE} 
                  alt="Super Grass-chan" 
                  className="w-80 h-80 md:w-[450px] md:h-[450px] mb-12 object-contain drop-shadow-[0_0_60px_rgba(74,222,128,0.8)]"
                  referrerPolicy="no-referrer"
                  animate={{ 
                    y: [0, -20, 0],
                    rotate: [-1, 1, -1]
                  }}
                  transition={{ 
                    duration: 4,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                />
                
                <button
                  onClick={startGame}
                  className="group relative bg-emerald-500 text-white px-16 py-6 rounded-full font-black text-2xl transition-all hover:scale-110 active:scale-95 flex items-center gap-4 shadow-[0_0_30px_rgba(16,185,129,0.4)]"
                >
                  <Play className="w-8 h-8 fill-current" />
                  GET HIGH
                  <div className="absolute -inset-2 bg-emerald-500/30 rounded-full blur-xl opacity-0 group-hover:opacity-100 transition-opacity" />
                </button>
                
                <div className="mt-12 grid grid-cols-2 gap-4 text-slate-500 text-xs uppercase font-bold">
                  <div className="bg-white/5 p-4 rounded-2xl border border-white/10">
                    <p className="mb-2">PC Controls</p>
                    <p className="text-white">A / D or Arrows</p>
                  </div>
                  <div className="bg-white/5 p-4 rounded-2xl border border-white/10">
                    <p className="mb-2">Mobile</p>
                    <p className="text-white">Tap Sides</p>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Game Over Screen */}
        <AnimatePresence>
          {gameState === 'GAMEOVER' && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-red-950/90 backdrop-blur-md flex flex-col items-center justify-center p-8 text-center"
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="flex flex-col items-center"
              >
                <img 
                  src={TITLE_IMAGE} 
                  alt="Super Grass-chan" 
                  className="w-48 h-48 mb-6 object-contain grayscale opacity-40 drop-shadow-[0_0_20px_rgba(239,68,68,0.2)]"
                  referrerPolicy="no-referrer"
                />
                <h2 className="text-5xl font-black text-white mb-2 tracking-tighter italic uppercase">
                  FALLEN!
                </h2>
                <div className="w-16 h-1 bg-red-500 mx-auto mb-8 rounded-full" />
                
                <div className="bg-white/5 p-8 rounded-3xl border border-white/10 mb-8">
                  <p className="text-red-300 text-xs uppercase font-bold tracking-widest mb-2">Final Score</p>
                  <p className="text-6xl font-black text-white mb-4 tracking-tighter">{score}</p>
                  
                  {score >= highScore && score > 0 && (
                    <div className="inline-flex items-center gap-2 bg-amber-500 text-amber-950 px-3 py-1 rounded-full text-xs font-black uppercase">
                      <Trophy className="w-3 h-3" />
                      New Best!
                    </div>
                  )}
                </div>

                <button
                  onClick={startGame}
                  className="bg-emerald-500 text-white px-12 py-4 rounded-full font-bold text-xl transition-all hover:scale-105 active:scale-95 flex items-center gap-3 mx-auto"
                >
                  <RotateCcw className="w-6 h-6" />
                  TRY AGAIN
                </button>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Mobile Controls */}
        {gameState === 'PLAYING' && (
          <div className="absolute inset-0 pointer-events-none flex">
            <div 
              className="w-1/2 h-full pointer-events-auto active:bg-white/5 transition-colors"
              onTouchStart={(e) => { e.preventDefault(); handleTouchStart('left'); }}
              onTouchEnd={(e) => { e.preventDefault(); handleTouchEnd('left'); }}
              onTouchCancel={(e) => { e.preventDefault(); handleTouchEnd('left'); }}
              onMouseDown={() => handleTouchStart('left')}
              onMouseUp={() => handleTouchEnd('left')}
              onMouseLeave={() => handleTouchEnd('left')}
            />
            <div 
              className="w-1/2 h-full pointer-events-auto active:bg-white/5 transition-colors"
              onTouchStart={(e) => { e.preventDefault(); handleTouchStart('right'); }}
              onTouchEnd={(e) => { e.preventDefault(); handleTouchEnd('right'); }}
              onTouchCancel={(e) => { e.preventDefault(); handleTouchEnd('right'); }}
              onMouseDown={() => handleTouchStart('right')}
              onMouseUp={() => handleTouchEnd('right')}
              onMouseLeave={() => handleTouchEnd('right')}
            />
          </div>
        )}
      </div>
    </div>
  );
}
